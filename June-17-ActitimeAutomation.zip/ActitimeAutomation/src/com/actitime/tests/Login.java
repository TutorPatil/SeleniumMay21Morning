package com.actitime.tests;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.TestNG;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.collections.Lists;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Login extends BaseClass{
	
	
	public static void main(String[] args) throws Exception {
		
	      
	      
	}	
	
	//@Test(priority = 2) // Order of execution
    //@Test(groups = { "smoke", "Login","login_001" })	
	//@Parameters({ "userName","password" })
	//@Test(dataProvider = "logindatafromexcel",dataProviderClass = com.actitime.DataProviders.class)
	//@Test(groups = { "smoke", "Login","login_001" },priority = 1,dataProvider = "logindatafromexcel",dataProviderClass = com.actitime.DataProviders.class)
	
	
	@Test(dataProvider = "logindatafromexcel",dataProviderClass = com.actitime.DataProviders.class)
	public static void login_001(String userName, String password) throws Exception
	{		
		boolean logoutLink = CommonUtils.loginToActiTime(userName,password);			
		Assert.assertTrue(logoutLink, "The Logout Link not displayed!!");	
		
		
	}	
	


	//@Test(priority = 1)
	//@Test(dependsOnMethods = { "login_001" })
	//@Test	
    //@Test(groups = { "regression", "Login","login_002" })
	//@Test
	
	@Test
	public static void login_002() throws Exception
	{
		
		boolean errorMsg =	CommonUtils.invalidLoginToActiTime("admin123", "afafaf");		
		
		Assert.assertTrue(errorMsg, "The error msg is not displayed!!");
		
			
	}
	
	
}
