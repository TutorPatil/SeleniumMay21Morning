package com.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.io.Files;

public class Jun8_RSynchronizationAndProjectSetup {
	
	static WebDriver driver ;

	public static void main(String[] args) throws Exception {
		locatorAndTestDataExternalized();
	}
	
	public static void locatorAndTestDataExternalized() throws Exception
	{

		
		String url = getConfigData("url");
		
		launchBrowser(url);
		
			
		driver.findElement(By.xpath(getLocatorData("Login","UserName_EidtBox"))).sendKeys(getTestData("Login", "UserName_EidtBox"));
		driver.findElement(By.xpath(getLocatorData("Login","Password_EditBox"))).sendKeys(getTestData("Login", "Password_EditBox"));		
		driver.findElement(By.xpath(getLocatorData("Login","Ok_Button"))).click();	
		
		//Explicit Wait
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("logoutLink")));
				
		boolean logoutLink = driver.findElement(By.xpath(getLocatorData("Home","Logout_Link"))).isDisplayed();
		
		if(logoutLink)
		{
			System.out.println("Login successful ");			
		}
		else
		{
			System.out.println("Could not login into Actitime");
		}
		
		
		closeBrowser();
		
		
	
	}
	

	
	
	public static String getLocatorData(String pageName, String elementName) throws IOException
	{
		String locator="";
		
		File f = new File("./data/locatordata.xlsx");
		
		FileInputStream fio = new FileInputStream(f);
		
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		int rows = ws.getLastRowNum();
		
		System.out.println(rows);
		
		for(int x=1;x<=rows;x++)
		{
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if((pageName.equalsIgnoreCase(page)) && (elementName.equalsIgnoreCase(element)))
			{
				locator = ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}
			
		}		
		wb.close();
		return locator;
	}
	
	public static String getTestData(String pageName, String elementName) throws IOException
	{
		String testData="";
		
		File f = new File("./data/testdata.xlsx");
		
		FileInputStream fio = new FileInputStream(f);
		
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		int rows = ws.getLastRowNum();
		
		System.out.println(rows);
		
		for(int x=1;x<=rows;x++)
		{
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if((pageName.equalsIgnoreCase(page)) && (elementName.equalsIgnoreCase(element)))
			{
				testData = ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}
			
		}		
		wb.close();
		return testData;
	}
	
	
	
	public static String getConfigData(String key) throws IOException
	{
		String value = "";
		
		File f = new File("./data/config.properties");	
		
		// Creating the object of FileInputStream to load the file as stream
		FileInputStream fis = new FileInputStream(f);
		
		// Creating the object of properties file
		Properties prop = new Properties();
		
		// Loading the stream
		prop.load(fis);
		
		
		value = prop.getProperty(key);
	
		
		
		return value;
	}
	
	
	
	
	public static void launchBrowser(String url) throws IOException
	{
		
		String browser = getConfigData("browser");
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");		
			driver = new ChromeDriver();		
			
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		String timeout = getConfigData("implicitwaittimeout");
		long time = Long.parseLong(timeout);
		
		// Implicit wait applicable through out the life cycle of the driver..
		driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);  // polling interval of 500 MS
		
		driver.get(url);
	}
	
	public static void closeBrowser()
	{
		driver.close();
	}


}
