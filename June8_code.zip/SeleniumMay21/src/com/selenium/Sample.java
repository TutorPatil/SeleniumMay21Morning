package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sample {
	
	public static void invalidLoginTestCase() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");		
		WebDriver driver = new ChromeDriver();
		//Second Test case..
		
		driver.get("https://demo.actitime.com/login.do");
	
		By b = By.xpath("//input[@id='username']");
		WebElement userName = driver.findElement(b);
		
		
		userName.sendKeys("admin123");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		Thread.sleep(5000);
		
		WebElement errorMsg = driver.findElement(By.xpath("(//span[@class='errormsg'])[1]"));
		
		if (errorMsg.isDisplayed())
		{
			String actualText = errorMsg.getText();
			if( actualText.equals("Username or Password is invalid. Please try again."))
				{
					System.out.println("Invalid login_002 pass..");		
				}
			
		}
		else
		{
			System.out.println("Invalid login_002 Failed.....");		
		}		
		
		driver.close();
	}
	
	public static void validLogin() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.actitime.com/login.do");
		
		System.out.println(driver.getTitle());
		
		System.out.println(driver.getCurrentUrl());
		
		// Create the object of the By class , using the static methods of By class
		By b = By.xpath("//input[@id='username']");
		
		// Creating the webElement Object
		WebElement userName = driver.findElement(b);
		
		userName.sendKeys("admin");
		
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		
		Thread.sleep(5000);
		
		boolean result = driver.findElement(By.xpath("//a[@id='logoutLink']")).isDisplayed();
		
		if(result)
		{
			System.out.println("Login test case passed");
		}
		else
		{
			System.out.println("Login Test case failed...");
		}
		
		driver.close();
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		validLogin();
		invalidLoginTestCase();
		
		
		
	}

}
