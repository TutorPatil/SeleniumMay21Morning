package com.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.io.Files;

public class Jun7_ReadingExcelFileAndCmdLine {
	
	static WebDriver driver ;

	public static void main(String[] args) throws Exception {
		dataDrivenTesting();
	}
	
	public static void locatorAndTestDataExternalized() throws Exception
	{

		
		String url = getConfigData("url");
		
		launchBrowser(url);
		
			
		driver.findElement(By.xpath(getLocatorData("Login","UserName_EidtBox"))).sendKeys(getTestData("Login", "UserName_EidtBox"));
		driver.findElement(By.xpath(getLocatorData("Login","Password_EditBox"))).sendKeys(getTestData("Login", "Password_EditBox"));		
		driver.findElement(By.xpath(getLocatorData("Login","Ok_Button"))).click();
		
		Thread.sleep(4000);
		
		boolean logoutLink = driver.findElement(By.xpath(getLocatorData("Home","Logout_Link"))).isDisplayed();
		
		if(logoutLink)
		{
			System.out.println("Login successful ");			
		}
		else
		{
			System.out.println("Could not login into Actitime");
		}
		
		
		closeBrowser();
		
		
	
	}
	
	public static void dataDrivenTesting() throws Exception
	{
		String users = getTestData("Login", "UserNameMultiData_EidtBox");
		String pwds = getTestData("Login", "PasswordMltiData_EditBox");
		
		String[] userData = users.split("#");
		String[] pwdData =  pwds.split("#");
		
		for(int x=0; x<userData.length;x++)
		{
				
		String url = getConfigData("url");
		
		launchBrowser(url);
		
			
		driver.findElement(By.xpath(getLocatorData("Login","UserName_EidtBox"))).sendKeys(userData[x]);
		driver.findElement(By.xpath(getLocatorData("Login","Password_EditBox"))).sendKeys(pwdData[x]);		
		driver.findElement(By.xpath(getLocatorData("Login","Ok_Button"))).click();
		
		Thread.sleep(4000);
		
		boolean logoutLink = driver.findElement(By.xpath(getLocatorData("Home","Logout_Link"))).isDisplayed();
		
		if(logoutLink)
		{
			System.out.println("Login successful ");			
		}
		else
		{
			System.out.println("Could not login into Actitime");
		}
		
		
		closeBrowser();
		}
		
	}
	
	public static String getLocatorData(String pageName, String elementName) throws IOException
	{
		String locator="";
		
		File f = new File("./data/locatordata.xlsx");
		
		FileInputStream fio = new FileInputStream(f);
		
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		int rows = ws.getLastRowNum();
		
		System.out.println(rows);
		
		for(int x=1;x<=rows;x++)
		{
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if((pageName.equalsIgnoreCase(page)) && (elementName.equalsIgnoreCase(element)))
			{
				locator = ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}
			
		}		
		wb.close();
		return locator;
	}
	
	public static String getTestData(String pageName, String elementName) throws IOException
	{
		String testData="";
		
		File f = new File("./data/testdata.xlsx");
		
		FileInputStream fio = new FileInputStream(f);
		
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		int rows = ws.getLastRowNum();
		
		System.out.println(rows);
		
		for(int x=1;x<=rows;x++)
		{
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if((pageName.equalsIgnoreCase(page)) && (elementName.equalsIgnoreCase(element)))
			{
				testData = ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}
			
		}		
		wb.close();
		return testData;
	}
	
	
	
	public static String getConfigData(String key) throws IOException
	{
		String value = "";
		
		File f = new File("./data/config.properties");	
		
		// Creating the object of FileInputStream to load the file as stream
		FileInputStream fis = new FileInputStream(f);
		
		// Creating the object of properties file
		Properties prop = new Properties();
		
		// Loading the stream
		prop.load(fis);
		
		
		value = prop.getProperty(key);
	
		
		
		return value;
	}
	
	
	
	
	public static void launchBrowser(String url) throws IOException
	{
		
		String browser = getConfigData("browser");
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");		
			driver = new ChromeDriver();		
			
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		driver.get(url);
	}
	
	public static void closeBrowser()
	{
		driver.close();
	}


}
