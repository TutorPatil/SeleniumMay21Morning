package com.selenium;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestDateFormat {

	public static void main(String[] args) {
		
		String date1 = "07/06/2021";
		String format = "dd/MM/yyyy";
		
		System.out.println(validateJavaDate(date1,format));
}
	
	
	public static boolean validateJavaDate(String strDate,String format)
	{
		
		 SimpleDateFormat sdfrmt = new SimpleDateFormat(format);
		 sdfrmt.setLenient(false);
		 
		 
		 try
		    {
		        Date javaDate = sdfrmt.parse(strDate);		        
		    }		   
		    catch (ParseException e)
		    {		       
		        return false;
		    }		  
		    return true;
		}
	
	}


