package com.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.io.Files;

public class June4_ProperiyFileExcelFiles {
	
	static WebDriver driver ;

	public static void main(String[] args) throws IOException {
		
		
		String url = getConfigData("url");
		
		launchBrowser(url);
		
			
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");		
		driver.findElement(By.xpath("//input[@id='keepLoggedInCheckBox']")).click();
		
		
	}
	
		
	
	
	public static String getConfigData(String key) throws IOException
	{
		String value = "";
		
		File f = new File("./data/config.properties");	
		
		// Creating the object of FileInputStream to load the file as stream
		FileInputStream fis = new FileInputStream(f);
		
		// Creating the object of properties file
		Properties prop = new Properties();
		
		// Loading the stream
		prop.load(fis);
		
		
		value = prop.getProperty(key);
	
		
		
		return value;
	}
	
	
	
	
	public static void launchBrowser(String url) throws IOException
	{
		
		String browser = getConfigData("browser");
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");		
			driver = new ChromeDriver();		
			
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		driver.get(url);
	}
	
	public static void closeBrowser()
	{
		driver.close();
	}


}
