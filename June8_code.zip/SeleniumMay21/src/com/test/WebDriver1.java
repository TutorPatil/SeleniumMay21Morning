package com.test;

public interface WebDriver1 {

	
	void get(String url);
	
	void close();
	
	String getTitle();	
	
	WebDriver1.Navigation navigate();
	
	Window manage();
	
	TimeOut setTime();
	
	
	public static interface Navigation{
		
		public void back();
		public void forward();
		public void refresh();
		
	}
	
	public static void getCurrentUrl()
	{
		System.out.println("Returning the URL...");
	}
	
	
	interface Window{
		
		void maximize();
		
		
	}
	
	
	interface TimeOut{
		
		void implicitlyWait();
		
		void SetTimeOut();
	}
	
	static interface Alert
	{
		void test();
	}

}



