package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;

import com.actitime.base.BaseClass;

public class Login extends BaseClass{
	
	
	public static void main(String[] args) throws IOException {
		login_001();
	}
	
	public static void login_001() throws IOException
	{
		try {
			launchBrowser();
			
			driver.findElement(By.xpath(getLocatorData("Login","UserName_EidtBox"))).sendKeys(getTestData("Login", "UserName_EidtBox"));
			driver.findElement(By.xpath(getLocatorData("Login","Password_EditBox"))).sendKeys(getTestData("Login", "Password_EditBox"));		
			driver.findElement(By.xpath(getLocatorData("Login","Ok_Button"))).click();
			
			boolean logoutLink = driver.findElement(By.xpath(getLocatorData("Home","Logout_Link"))).isDisplayed();
			
			if(logoutLink)
			{
				writeResultsToFile("Login_001", "Pass");
				System.out.println("Login successful ");			
			}
			else
			{
				writeResultsToFile("Login_001", "Failed");
				captureScreenShot("Login_001");
				System.out.println("Could not login into Actitime");
			}
			
		}
		catch(Exception e)
		{
			writeResultsToFile("Login_001", "Failed");
			captureScreenShot("Login_001");
			
		}
		finally
		{
			closeBrowser();
		}
	}

}
