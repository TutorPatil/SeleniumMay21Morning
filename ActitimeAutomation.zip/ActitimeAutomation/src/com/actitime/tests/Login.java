package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Login extends BaseClass{
	
	
	public static void main(String[] args) throws Exception {
	
				
	}
	
	// Randomizing the customer Name 
	//String customerName = "AutoCustomer_" + System.currentTimeMillis();		
	//System.out.println(customerName);
	
	
	@Test
	public static void login_001() throws Exception
	{
		try {
			launchBrowser();		
			boolean logoutLink = CommonUtils.loginToActiTime();
			
			CommonUtils.selectModule("Tasks");
			Thread.sleep(2000);
			CommonUtils.selectModule("Reports");
			
			if(logoutLink)
			{
				writeResultsToFile("Login_001", "Pass");
				System.out.println("Login successful ");			
			}
			else
			{
				writeResultsToFile("Login_001", "Failed");
				captureScreenShot("Login_001");
				System.out.println("Could not login into Actitime");
			}
			
		}
		catch(Exception e)
		{
			writeResultsToFile("Login_001", "Failed");
			captureScreenShot("Login_001");
			
		}
		finally
		{
			closeBrowser();
		}
	}
	
	
	public static void login_002() throws IOException
	{
		try {
			
			launchBrowser();
			boolean errorMsg =	CommonUtils.invalidLoginToActiTime("admin123", "afafaf");		
			System.out.println(errorMsg);
			
			if(errorMsg)
			{
				writeResultsToFile("Login_002", "Pass");
				System.out.println("In validLogin Pass ");			
			}
			else
			{
				writeResultsToFile("Login_002", "Failed");
				captureScreenShot("Login_002");
				System.out.println("In validLogin Fail");
			}
			
		}		
		catch(Exception e)
		{
			writeResultsToFile("Login_002", "Failed");
			captureScreenShot("Login_002");			
		}
		finally
		{
			closeBrowser();
		}
	}

}
