package com.actitime.utils;

import com.actitime.base.BaseClass;

public class CommonUtils extends BaseClass{

}
