package com.actitime.utils;

import java.io.IOException;

import org.openqa.selenium.By;

import com.actitime.base.BaseClass;

public class CommonUtils extends BaseClass{
	
	public static boolean loginToActiTime() throws IOException
	{
		boolean logoutLink = false;
		
		driver.findElement(By.xpath(getLocatorData("Login","UserName_EidtBox"))).sendKeys(getTestData("Login", "UserName_EidtBox"));
		driver.findElement(By.xpath(getLocatorData("Login","Password_EditBox"))).sendKeys(getTestData("Login", "Password_EditBox"));		
		driver.findElement(By.xpath(getLocatorData("Login","Ok_Button"))).click();
		
		try
		{
			logoutLink = driver.findElement(By.xpath(getLocatorData("Home","Logout_Link"))).isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("The logout link not displayed");
		}
		
		return logoutLink;
		
	}
	
	
	public static boolean invalidLoginToActiTime(String invalidUser, String  invalidPassword) throws Exception
	{
		boolean errorMsg = true;
		
		driver.findElement(By.xpath(getLocatorData("Login","UserName_EidtBox"))).sendKeys(invalidUser);
		driver.findElement(By.xpath(getLocatorData("Login","Password_EditBox"))).sendKeys(invalidPassword);		
		driver.findElement(By.xpath(getLocatorData("Login","Ok_Button"))).click();
		
		Thread.sleep(3000);
		
		try
		{
			errorMsg = driver.findElement(By.xpath(getLocatorData("Login","ErrorMsg_Text"))).isDisplayed();
		}
		catch(Exception e)
		{
			errorMsg = false;
			e.printStackTrace();
			System.out.println("The error message is not displayed");
		}
		
		return errorMsg;
		
	}
	
	public static void selectModule(String moduleName) throws Exception
	{
		String module = getLocatorData("Home","ModuleName_Text");
		String moduleNameXpath = module.replace("--TEXTREPLACE--", moduleName);		
		driver.findElement(By.xpath(moduleNameXpath)).click();
		
		
	}


}
