package com.actitime.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.pages.HomePage;
import com.actitime.pages.LoginPage;

public class LoginPageTest extends BaseClass{
	
	@Test
	public static void login_001()
	{
		// Creating the object of LoginPage
		LoginPage login = new LoginPage(driver);
		
		login.setUserName("admin");
		login.setPassword("manager");
		
		// Inside this method Object of HomePage gets created..
		HomePage home = login.clickLoginButton(driver);		
		boolean result = home.verifyLogoutLinkDisplay();
		
		Assert.assertTrue(result, "Login_001 Failed");
		
	}

}
