package com.actitime.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	
	private WebDriver driver;	
	
	
	// Declaring all the WebElements as private global variables
	@FindBy(id="username")
	private WebElement userName;
	
	@FindBy(how=How.NAME,using="pwd")
	private WebElement password;
	
	
	@FindBy(how=How.XPATH,using="//a[@id='loginButton']")
	private WebElement loginButton;
	
	
	public void setUserName(String usernameData)
	{
		userName.sendKeys(usernameData);
	}
	
	
	public void setPassword(String passwordData)
	{
		password.sendKeys(passwordData);
	}
	
	
	// This method clicks on OK btn and creats the object of Home page
	public HomePage clickLoginButton(WebDriver driver)
	{
		loginButton.click();
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		
		//LoginPage login = new LoginPage(driver);
		HomePage home = new HomePage(driver);
		return home;
		
	}
	
	// Constructor which initializes all the WebElements , when the object of this class is created
	public LoginPage(WebDriver driver)
	{
		
		PageFactory.initElements(driver, this);
	}
		
	

}
