package com.actitime.tests;

import com.actitime.utils.CommonUtils;

public class MisceleneousTopics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
	// Randomizing the customer Name 
	//String customerName = "AutoCustomer_" + System.currentTimeMillis();		
	//System.out.println(customerName);
	
	
	// Selecting a module using the method
	//CommonUtils.selectModule("Tasks");
	//Thread.sleep(2000);
	//CommonUtils.selectModule("Reports");
	
	
}
