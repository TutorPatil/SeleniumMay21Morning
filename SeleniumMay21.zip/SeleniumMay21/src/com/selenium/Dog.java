package com.selenium;

public class Dog {
	
	
	public static Dog xpath(String s)
	{
		Dog d = new Dog();
		return d;
	}
	
	public void eat()
	{
		System.out.println("The dog is eating....");
	}
	
	public static void main(String[] args) {
		
		Dog d = Dog.xpath("sdasdda");
		d.eat();
	}

}
