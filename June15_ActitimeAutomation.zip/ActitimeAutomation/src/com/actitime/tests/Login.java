package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Login extends BaseClass{
	
	
	public static void main(String[] args) throws Exception {
	
		
	}	
	
	//@Test(priority = 2) // Order of execution
	//@Test
	
    //@Test(groups = { "smoke", "Login","login_001" })
	
	@Parameters({ "userName","password" })
	@Test
	public static void login_001(String userName, String password) throws Exception
	{

			
			System.out.println("Starting the test case Login_001");
			boolean logoutLink = CommonUtils.loginToActiTime(userName,password);
			
			Assert.assertTrue(logoutLink, "The Logout Link not displayed!!");
			
			writeResultsToFile("Login_001", "Pass");
			
			System.out.println("Ending  the test case Login_001");
			
			/*
			//Assert Equals Ex			
			int expectedCount = 10;
			int ActualCount = 10;
			
			Assert.assertEquals(expectedCount, ActualCount,"The count of users did not match!!");
			*/
			
		
	}

	//@Test(priority = 1)
	//@Test(dependsOnMethods = { "login_001" })
	//@Test
    
    //@Test(groups = { "regression", "Login","login_002" })
	//@Test
	public static void login_002() throws Exception
	{
	
			System.out.println("Starting the test case Login_002");
			boolean errorMsg =	CommonUtils.invalidLoginToActiTime("admin123", "afafaf");		
			
			//Assert.assertFalse(errorMsg, "The error msg is displayed");
			Assert.assertTrue(errorMsg, "The error msg is not displayed!!");
			
			writeResultsToFile("Login_002", "Pass");
			System.out.println("Ending  the test case Login_002");
	}

}
