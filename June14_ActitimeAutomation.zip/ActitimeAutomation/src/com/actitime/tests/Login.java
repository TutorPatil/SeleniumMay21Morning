package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Login extends BaseClass{
	
	
	public static void main(String[] args) throws Exception {
	
		
	}	
	
	//@Test(priority = 2) // Order of execution
	@Test
	public static void login_001() throws Exception
	{

			
			boolean logoutLink = CommonUtils.loginToActiTime();	
			
			Assert.assertFalse(logoutLink, "The Logout Link not displayed!!");
			
			writeResultsToFile("Login_001", "Pass");
			
			/*
			//Assert Equals Ex			
			int expectedCount = 10;
			int ActualCount = 10;
			
			Assert.assertEquals(expectedCount, ActualCount,"The count of users did not match!!");
			*/
			
		
	}

	//@Test(priority = 1)
	@Test(dependsOnMethods = { "login_001" })
	public static void login_002() throws Exception
	{
	
			
			boolean errorMsg =	CommonUtils.invalidLoginToActiTime("admin123", "afafaf");		
			
			//Assert.assertFalse(errorMsg, "The error msg is displayed");
			Assert.assertTrue(errorMsg, "The error msg is not displayed!!");
			
			writeResultsToFile("Login_002", "Pass");
		
	}

}
